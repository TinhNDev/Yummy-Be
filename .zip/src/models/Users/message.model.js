module.exports = (sequelize, Sequelize) =>{
    const Message = sequelize.define("Message",{
        
    })
    return Message;
}