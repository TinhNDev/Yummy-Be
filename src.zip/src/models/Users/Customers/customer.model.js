module.exports = (sequelize, Sequelize) => {
  const Customer = sequelize.define("Customer", {

  });
  return Customer;
};
